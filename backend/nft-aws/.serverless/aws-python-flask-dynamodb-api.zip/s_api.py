import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jrauch123',
    application_name='app',
    app_uid='ZQXdxkxDLDdMsqwjNd',
    org_uid='f8121395-a650-4d84-86b5-2e932eade5e7',
    deployment_uid='1e50f804-55e7-4ad7-b177-38e0241ee841',
    service_name='aws-python-flask-dynamodb-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-flask-dynamodb-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
